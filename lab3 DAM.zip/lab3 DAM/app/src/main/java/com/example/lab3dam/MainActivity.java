package com.example.lab3dam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public int count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView text_view = findViewById(R.id.textView);
        Button Bt_toast = findViewById(R.id.buttonToast);

        Bt_toast.setOnClickListener(v -> {
            text_view.setText("Start!");
            count=0;
        });

        Button Bt_count=findViewById(R.id.buttonCount);

        Bt_count.setOnClickListener(v -> {
            count++;
            text_view.setText(String.valueOf(count));
        });
    }

}